package TwoDayspackage;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author me
 */
public interface AllFrames {
    public static MainFrame mf = new MainFrame();
    public static LoginFrame lf = new LoginFrame();
    public static RegisterFrame rf = new RegisterFrame();
    public static ActionsFrame af = new ActionsFrame();
    public static AddMoney am = new AddMoney();
    public static YourAssetsFrame yaf = new YourAssetsFrame();
    public static TransactionFrame tf = new TransactionFrame();
    public static SellAssetFrame saf = new SellAssetFrame();
    public static BuyAssetFrame baf = new BuyAssetFrame();
}
